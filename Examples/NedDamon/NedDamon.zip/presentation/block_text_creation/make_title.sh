#!/bin/bash

python blocktext_xe.py thesis_title.txt Trade Gothic LT Bold
#python blocktext_xe.py thesis_thankyou.txt LTZapfino Four
