#!/bin/bash
python macro_s.py 5 &
python macro_s.py 4 &
python macro_s.py 3 &
python macro_s.py 2 &
python macro_s.py 1 &
